#Instructions
In this assignment you will take my HTML code and create a single html file called hw1.css.  It should style the page following the guidelines provided.  You can see an example final product <a href="http://www.intro-webdesign.com/CSS/assignment-1/index.jpg">here</a>. 
##Steps:

Create a file called hw1.css and save it in your css folder. 

1) Style the page using the following rules: 

2) Style the header with a background color 

3) h1 elements should be centered and have a new font color 

4) h2 elements have a new font color 

5) sections should have a new background color 

6) h1 elements should be centered and have a new font color and background color 

7 ) the images should not be on the page 